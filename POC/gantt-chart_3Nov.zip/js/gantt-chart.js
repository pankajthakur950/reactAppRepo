// 9fbef606107a605d69c0edbcd8029e5d_design_systems
$(document).ready(function () {
	var selector = {
		"CATEGORY_LIST": ".category-list",
		"CATEGORY_ITEM_TEMPLATE": "#category-item-template",
		"GANTT_CHART_BAR" : ".request-duration-bar-container .bar"
	}
	
	var categoryLeftPanelWidth = 200;
	var categoryListWidth = $(selector.CATEGORY_LIST).width();
	var ganttChartWidth = categoryListWidth - categoryLeftPanelWidth;
     
	var CHART_TIMELINE_VIEW = {
		"MONTHLY" : "monthly",
		"QUARTERLY": "quarterly",
		"YEARLY": "yearly"
	}
	var currentViewType = CHART_TIMELINE_VIEW.MONTHLY;
	
	var MONTH_DAY_MAP = {
		"OCTOBER" : 31,
		"NOVEMBER" : 30
	};
	var currentMonth = "October";
	
	var ganttChartData = {};
	var widthPerDate = (ganttChartWidth/MONTH_DAY_MAP.OCTOBER).toFixed(3);
	
	var CHART_DIVIDER_MAP = {
		"MONTHLY" : 30,
		"QUARTERLY" : 2,
		"YEARLY" : 2
	}
	var numberOfDividerLinesInChart = CHART_DIVIDER_MAP.MONTHLY;
	
	function generateChartData(){
		requests.map(function(request){
			if(!ganttChartData[request.category] && request.category != ""){
				ganttChartData[request.category] = []
			}
			if(request.category != ""){
				ganttChartData[request.category].push(request);
			}
		});
	}
	
	function generateChartTimeline(monthDays){
		var monthDays = MONTH_DAY_MAP[currentMonth.toUpperCase()];
		$(".ups-ds-gantt-calendar").empty();
		widthPerDate = (ganttChartWidth/monthDays).toFixed(3);
		numberOfDividerLinesInChart = monthDays - 1;
		var areasInChart = numberOfDividerLinesInChart+1;
		var baseDividerPosition = (monthDays / areasInChart) * widthPerDate ;
		for(var i=1; i <= numberOfDividerLinesInChart ; i++){
			var $dividerSpan = $("<span class='divider'>"+(i+1)+"</span>");
			var dividerPosition = ((i * baseDividerPosition)/ganttChartWidth).toFixed(3) * 100;
			$dividerSpan.css({
				left : dividerPosition + '%',
			});
			$(".ups-ds-gantt-calendar").append($dividerSpan);
		}
	}
	
	function generateGanttChart(){
		var monthDays = MONTH_DAY_MAP[currentMonth];
		var $categoryList = $(selector.CATEGORY_LIST);
		$categoryList.empty();
		for (var requestEntry of Object.entries(ganttChartData)) {
			var requestCountCurrentMonth = 0;
			//get category value
			var category = requestEntry[0];
			//get requests array for category 
			var categoryRequests = requestEntry[1];
			
			var $categoryItemTemplate = $($(selector.CATEGORY_ITEM_TEMPLATE).html());
			var $categoryRequestList = $categoryItemTemplate.find(".request-list");
			
			$.each(categoryRequests, function (index, request) {
				var $requestItemTemplate = $($('#request-item-template').html());
				var $requestItemBar = $requestItemTemplate.find(selector.GANTT_CHART_BAR);
				var $requestItemHeader = $requestItemTemplate.find(".request-id");
				var requestStartDate = moment(request.startDate,"MM/DD/YYYY");
				var requestEndDate = moment(request.endDate,"MM/DD/YYYY");
				var requestStartDay = requestStartDate.format("D");
				var requestEndDay = requestEndDate.format("D");
				var barWidth, barPosition;
				console.log(requestStartDate.format("MMMM"));
				if(requestStartDate.format("MMMM") != currentMonth && requestEndDate.format("MMMM") != currentMonth){
					return;
				}
				$requestItemHeader.text(request.requestID);
				
				if(requestStartDate.format("MMMM") == currentMonth){
					barWidth = (requestEndDate.diff(requestStartDate, "days") + 1) * widthPerDate;
					barPosition = requestStartDay == 1 ? 0 : (requestStartDay-1) * widthPerDate;
				}else{
					barWidth = requestEndDay * widthPerDate;
					barPosition = 0;
				}
				//if bar going ahead of chart area
				if(barWidth + barPosition > ganttChartWidth){
					barWidth = ganttChartWidth - barPosition;
				}else{
					$requestItemBar.addClass("rounded");
				}
				$requestItemBar.addClass(request.status.toLowerCase());
				console.log(request.requestID+"->"+barWidth);
				$requestItemBar.css({
					width: (((barWidth/ganttChartWidth).toFixed(3))*100) + '%',
					left: (((barPosition/ganttChartWidth).toFixed(3))*100) + '%'
				});
				$categoryRequestList.append($requestItemTemplate.get(0));
				requestCountCurrentMonth++;
			});
			//create category header
			$categoryItemTemplate.attr("data-category-header", category+"("+requestCountCurrentMonth+")");
			
			//if there is requests in current month, only then show the particular category
			if(requestCountCurrentMonth > 0){
				$categoryList.append($categoryItemTemplate.get(0));
			}
			
		};
	}
	
	generateChartData();
	generateChartTimeline();
	generateGanttChart();
	
	$(".next-month").on("click", function(){
		currentMonth = "November";
		generateChartTimeline();
		generateGanttChart();
	});
	$(".prev-month").on("click", function(){
		currentMonth = "October";
		generateChartTimeline();
		generateGanttChart();
	});
			
	window.addEventListener("resize", function(){
		//console.log($(".category-list").width() - 210);
	}, false);
});