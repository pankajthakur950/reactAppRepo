// 9fbef606107a605d69c0edbcd8029e5d_design_systems
$(document).ready(function () {
	var selector = {
		"CATEGORY_LIST": ".category-list",
		"CATEGORY_ITEM_TEMPLATE": "#category-item-template",
		"GANTT_CHART_BAR" : ".request-duration-bar-container .bar"
	}
	
	var categoryLeftPanelWidth = 200;
	var categoryListWidth = $(selector.CATEGORY_LIST).width();
	var ganttChartWidth = categoryListWidth - categoryLeftPanelWidth;
     
	var CHART_TIMELINE_VIEW = {
		"MONTHLY" : "monthly",
		"QUARTERLY": "quarterly",
		"HALFYEARLY": "halfyearly"
	}
	var currentViewType = CHART_TIMELINE_VIEW.HALFYEARLY;
	
	var ganttChartData = {}, widthPerDate, currentDate, chartStartDate, chartEndDate, numberOfDividerLinesInChart;
	
	function generateChartData(){
		requests.map(function(request){
			if(!ganttChartData[request.category] && request.category != ""){
				ganttChartData[request.category] = []
			}
			if(request.category != ""){
				ganttChartData[request.category].push(request);
			}
		});
	}
	
	function generateChartTimeline(numberOfLines){
		$(".ups-ds-gantt-calendar").empty();
		var widthPerLine = (ganttChartWidth/numberOfLines).toFixed(3);
		numberOfDividerLinesInChart = numberOfLines - 1;
		var areasInChart = numberOfDividerLinesInChart+1;
		var baseDividerPosition = (numberOfLines / areasInChart) * widthPerLine ;
		for(var i=1; i <= numberOfDividerLinesInChart ; i++){
			var $dividerSpan = $("<span class='divider'>"+(i+1)+"</span>");
			var dividerPosition = ((i * baseDividerPosition)/ganttChartWidth).toFixed(3) * 100;
			$dividerSpan.css({
				left : dividerPosition + '%',
			});
			$(".ups-ds-gantt-calendar").append($dividerSpan);
		}
	}
	
	function generateGanttChart(){
		var $categoryList = $(selector.CATEGORY_LIST);
		$categoryList.empty();
		var numberOfDaysInView = chartEndDate.diff(chartStartDate, "days") + 1;
		console.log(numberOfDaysInView);
		widthPerDate = (ganttChartWidth/numberOfDaysInView).toFixed(3);
		for (var requestEntry of Object.entries(ganttChartData)) {
			var requestCountCurrentMonth = 0;
			//get category value
			var category = requestEntry[0];
			//get requests array for category 
			var categoryRequests = requestEntry[1];
			
			var $categoryItemTemplate = $($(selector.CATEGORY_ITEM_TEMPLATE).html());
			var $categoryRequestList = $categoryItemTemplate.find(".request-list");
			
			$.each(categoryRequests, function (index, request) {
				var $requestItemTemplate = $($('#request-item-template').html());
				var $requestItemBar = $requestItemTemplate.find(selector.GANTT_CHART_BAR);
				var $requestItemHeader = $requestItemTemplate.find(".request-id");
				var requestStartDate = moment(request.startDate,"MM/DD/YYYY");
				var requestEndDate = moment(request.endDate,"MM/DD/YYYY");
				var barWidth, barPosition;
				
				var isRequestStartDateInChart = requestStartDate.isBetween(chartStartDate, chartEndDate, undefined, []);
				var isRequestEndDateInChart = requestEndDate.isBetween(chartStartDate, chartEndDate, undefined, []);
				var isRequestRangesInChart = chartStartDate.isBetween(requestStartDate, requestEndDate, undefined, []);
				if(!(isRequestStartDateInChart || isRequestEndDateInChart || isRequestRangesInChart)){
					return;
				}
				$requestItemHeader.text(request.requestID);
				if(isRequestStartDateInChart){
					barWidth = (requestEndDate.diff(requestStartDate, "days") + 1) * widthPerDate;
					//console.log(request.requestID + "-->");
					//console.log(requestStartDate == chartStartDate);
					barPosition = requestStartDate.diff(chartStartDate, "days") * widthPerDate;
				}else{
					barWidth = (requestEndDate.diff(chartStartDate, "days") + 1) * widthPerDate;
					barPosition = 0;
				}
				//if bar going ahead of chart area
				if(barWidth + barPosition > ganttChartWidth){
					barWidth = ganttChartWidth - barPosition;
				}else{
					$requestItemBar.addClass("rounded");
				}
				$requestItemBar.addClass(request.status.toLowerCase());
				$requestItemBar.css({
					width: (((barWidth/ganttChartWidth).toFixed(3))*100) + '%',
					left: (((barPosition/ganttChartWidth).toFixed(3))*100) + '%'
				});
				$categoryRequestList.append($requestItemTemplate.get(0));
				requestCountCurrentMonth++;
			});
			//create category header
			$categoryItemTemplate.attr("data-category-header", category+"("+requestCountCurrentMonth+")");
			
			//if there is requests in current month, only then show the particular category
			if(requestCountCurrentMonth > 0){
				$categoryList.append($categoryItemTemplate.get(0));
			}
			
		};
	}
	
	function loadGanttChart(){
				
		switch(currentViewType){
			case CHART_TIMELINE_VIEW.MONTHLY:
				chartStartDate = moment(currentDate).startOf('month');
				chartEndDate = moment(currentDate).endOf('month');
				generateChartTimeline(currentDate.daysInMonth());
				break;
			case CHART_TIMELINE_VIEW.QUARTERLY:
				chartStartDate = moment(currentDate).startOf('quarter');
				chartEndDate = moment(currentDate).endOf('quarter');
				generateChartTimeline(7);
				break;
			case CHART_TIMELINE_VIEW.HALFYEARLY:
				var quarter = moment(currentDate).quarter();
				if(quarter == 1 || quarter == 2){
					chartStartDate = moment(currentDate).startOf('year');
					chartEndDate = moment(chartStartDate).add(6, 'months').subtract(1, 'days');
				}else{
					chartEndDate = moment(currentDate).endOf('year');
					chartStartDate = moment(chartEndDate).subtract(6, 'months').add(1, 'days');
				}
				generateChartTimeline(6);
				break;
		}
		generateGanttChart();
	}
	
	generateChartData();
	currentDate = moment();
	loadGanttChart();
	
	$(".next-month").on("click", function(){
		currentDate = moment(currentDate).add(1, 'months');
		loadGanttChart();
	});
	$(".prev-month").on("click", function(){
		currentDate = moment(currentDate).subtract(1, 'months');
		loadGanttChart();
	});
	$(".half-yearly-view").on("click", function(){
		currentDate = moment();
		currentViewType = CHART_TIMELINE_VIEW.HALFYEARLY;
		loadGanttChart();
	});
	$(".monthly-view").on("click", function(){
		currentDate = moment();
		currentViewType = CHART_TIMELINE_VIEW.MONTHLY;
		loadGanttChart();
	});
	$(".quarterly-view").on("click", function(){
		currentDate = moment();
		currentViewType = CHART_TIMELINE_VIEW.QUARTERLY;
		loadGanttChart();
	});
			
	window.addEventListener("resize", function(){
		//console.log($(".category-list").width() - 210);
	}, false);
});